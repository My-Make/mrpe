#include <Wire.h>

#define SLAVE1_ADRS 1
#define SLAVE2_ADRS 2

#define CMD_PINSETUP 1
#define CMD_PINWRITE 2
#define CMD_PINREAD 3
#define CMD_PORTREAD 4

#define ERROR -1
#define NO_ERROR 0

    // slave2: {85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128;  
  	// slave1: {43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, --, --};  
  	// master: {01, 02, 03, 04, 05, 06, 07, 08, 09, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, --, --};  
int myPins[] = {22, 23, 24, 25, 26, 27, 28, 29, 53, 52, 51, 50, 10, 11, 12, 13, 37, 36, 35, 34, 33, 32, 31, 30, 41, 40, 39,  4, 17, 16,  6,  7,  8,  9, 49, 48, 47, 46, 45, 44, 43, 42, 19, 18};


void setup() {
    
    Wire.begin();  // Avvia la comunicazione I2C
    Wire.setClock(10000);


    Serial.begin(115200);
}

void pinSetup(uint8_t pin, uint8_t mode) {
  uint8_t addr;
  uint8_t p;
  if (mode >= INPUT && mode <= INPUT_PULLUP) {
    if (pin > 41) {
      if (pin < 84) {
        addr = SLAVE1_ADRS;
        p = pin - 42;
      }
      else {
        addr = SLAVE2_ADRS;
        p = pin - 84;
      }
      Wire.beginTransmission(addr);
      Wire.write(CMD_PINSETUP);
      Wire.write(p);
      Wire.write(mode);
      Wire.endTransmission();       
    }
    else {
      pinMode(myPins[pin],mode);
    }
  }
}

int pinRead(uint8_t pin) {
  uint8_t addr;
  uint8_t p;
  int value;
  if (pin > 41) {
    if (pin < 84) {
        addr = SLAVE1_ADRS;
        p = pin - 42;      
    }
    else {
        addr = SLAVE2_ADRS;
        p = pin - 84;
    }
    Wire.beginTransmission(addr);
    Wire.write(CMD_PINREAD);
    Wire.write(p);
    Wire.endTransmission();  
    Wire.requestFrom((int)addr, 2);
    while (Wire.available() < 2) {}
    int err = Wire.read();
    value = Wire.read();
    if (err != NO_ERROR) {
      value = ERROR;
    }
  }
  else {
    value = digitalRead(myPins[pin]);
  }
  return value;
}

void pinWrite(uint8_t pin, uint8_t value) {
    uint8_t addr;
    uint8_t p;
    if (pin > 41) {
    if (pin < 84) {
        addr = SLAVE1_ADRS;
        p = pin - 42;      
    }
    else {
        addr = SLAVE2_ADRS;
        p = pin - 84;
    }
    Wire.beginTransmission(addr);
    Wire.write(CMD_PINWRITE);
    Wire.write(p);
    Wire.write(value);
    Wire.endTransmission();  
  }
  else {
    digitalWrite(myPins[pin], value);
  }
  
}






void loop() {
    char comando;
    Serial.println("Invia comando: (s) Setup, (w) Write, (r) Read, (p) Read Ports");
    while (!Serial.available());
    comando = Serial.read();

    if (comando == 's') {  // Setup pin
        int pin, mode;
        Serial.print("Pin da configurare: ");
        while (!Serial.available());
        pin = Serial.parseInt();

        Serial.print("Modo (0=INPUT, 2=INPUT PULLUP, 1=OUTPUT): ");
        while (!Serial.available());
        mode = Serial.parseInt();

        /*Wire.beginTransmission(SLAVE1_ADRS);
        Wire.write(CMD_PINSETUP);
        Wire.write(pin);
        Wire.write(mode);
        Wire.endTransmission();*/

        pinSetup(pin, mode);
        Serial.println("Setup inviato!");

    } else if (comando == 'w') {  // Scrivi sul pin
        int pin, value;
        Serial.print("Pin da scrivere: ");
        while (!Serial.available());
        pin = Serial.parseInt();

        Serial.print("Valore (0=Basso, 1=Alto): ");
        while (!Serial.available());
        value = Serial.parseInt();

        /*Wire.beginTransmission(SLAVE1_ADRS);
        Wire.write(CMD_PINWRITE);
        Wire.write(pin);
        Wire.write(value);
        Wire.endTransmission();*/
        pinWrite(pin, value);
        Serial.println("Valore inviato!");

    } else if (comando == 'r') {  // Leggi dal pin
        int pin;
        Serial.print("Pin da leggere: ");
        while (!Serial.available());
        pin = Serial.parseInt();

        /*Wire.beginTransmission(SLAVE1_ADRS);
        Wire.write(CMD_PINREAD);
        Wire.write(pin);
        Wire.endTransmission();
        Wire.requestFrom(SLAVE1_ADRS, 2);
        delay(10);
        if (Wire.available()) {
            while (Wire.available() > 0) {
              int value = Wire.read();
              Serial.print("Valore letto: ");
              Serial.println(value);
            }
        }*/

        int value = pinRead(pin);

        Serial.print("Valore letto: ");
        Serial.println(value);


     } else if (comando == 'p') {  // Leggi dal pin
        int pin;
        Serial.print("Port da leggere (0-6): ");
        while (!Serial.available());
        pin = Serial.parseInt();

       /* Wire.beginTransmission(SLAVE1_ADRS);
        Wire.write(CMD_PORTREAD);
        Wire.write(pin);
        Wire.endTransmission();
        Wire.requestFrom(SLAVE1_ADRS, 2);
        //delay(10);
        if (Wire.available()) {
            while (Wire.available() > 0) {
              int value = Wire.read();
              Serial.print("Valore letto: ");
              Serial.println(value);
            }
        }*/
        uint8_t device = 1;
        uint8_t port =0;
			Wire.beginTransmission(device);
			Wire.write(CMD_PORTREAD);
			Wire.write(port);
			Wire.endTransmission();  
			Wire.requestFrom((int)device, 2);
			while (Wire.available() < 2) {}
			int err = Wire.read();
			int value = Wire.read();
      Serial.print("Valore letto: ");
      Serial.println(value);


    } else if (comando == 'x') {
        Serial.println(OUTPUT);
        Serial.println(INPUT);
        Serial.println(INPUT_PULLUP);
    }

    ///delay(500);
}