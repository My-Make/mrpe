#include <Wire.h>

#define SLAVE_ADRS 2	//Configure slave 1 or slave 2

#define CMD_PINSETUP 1
#define CMD_PINWRITE 2
#define CMD_PINREAD 3
#define CMD_PORTREAD 4
#define CMD_PINALLIN 5
#define CMD_GETPINMODE 6
#define CMD_ALLPINSSETUP 7

#define ERROR 0xFF
#define NO_ERROR 0

#define WIRE_CLOCK 10000

const volatile uint8_t* pinsRegistry[] = {&PINA, &PINB, &PINC, &PIND, &PING, &PINH, &PINL};

uint8_t myPins[] = {22, 23, 24, 25, 26, 27, 28, 29, 53, 52, 51, 50, 10, 11, 12, 13, 37, 36, 35, 34, 33, 32, 31, 30, 41, 40, 39, 4, 17, 16, 6, 7, 8, 9, 49, 48, 47, 46, 45, 44, 43, 42, 19, 18};
uint8_t myPinsMode[44];
uint8_t pinValue[] = {1, 2};

uint8_t pin = 0;
uint8_t mode = 0;
uint8_t value = 0;

uint8_t op = 0;

void setup() {
  setInputs();
  Wire.begin(SLAVE_ADRS);
  Wire.setClock(WIRE_CLOCK);
  Wire.onRequest(i2c_request);
  Wire.onReceive(i2c_receive);
  // Serial.begin(115200);
}

/* Set all lines as input except used by i2c */
void setInputs() {
  DDRA = 0;
  PORTA = 0xFF;
  DDRB = 0;
  PORTB = 0xFF;
  DDRC = 0;
  PORTC = 0xFF;
  DDRD = 0;
  PORTD = 0x0C;
  DDRG = 0;
  PORTG = 0x27;
  DDRH = 0;
  PORTH = 0x7B;
  DDRL = 0;
  PORTL = 0xFF;
  DDRE = B00110000;
  memset(myPinsMode, INPUT_PULLUP, sizeof(myPinsMode));
}

//This routine is called when master perform a i2c Wire.requestFrom command
void i2c_request () {
  if (op == ERROR) {
    Wire.write(ERROR);
    Wire.write(ERROR);
  }
  else {
    Wire.write(NO_ERROR);
    Wire.write(value);
  }
  op = 0;  
}

//This routine is called when master perform a i2c Wire.write command
void i2c_receive (int numBytes) {
  if (numBytes < 2) return;
    uint8_t cmd = Wire.read();
    if (cmd == CMD_PINSETUP && numBytes == 3) {
      pin = Wire.read();
      mode = Wire.read();
      if (mode >= INPUT && mode <= INPUT_PULLUP) {
        pinMode(myPins[pin], mode);
        myPinsMode[pin] = mode;
      }
    }
    else if (cmd == CMD_ALLPINSSETUP && numBytes == 2) {
      mode = Wire.read();
      if (mode >= INPUT && mode <= INPUT_PULLUP) {
        for (int i = 0; i < 44; i++) {
          pinMode(myPins[i], mode);
          myPinsMode[i] = mode;
          Serial.println(myPins[i]);
        }
        memset(myPinsMode, mode, sizeof(myPinsMode));
        Serial.println(mode);
      }
    }
    else if (cmd == CMD_PINWRITE && numBytes == 3) {
      pin = Wire.read();
      value = Wire.read();  
      if (myPinsMode[pin] == OUTPUT) {
        digitalWrite(myPins[pin], value);
      }
    }
    else if (cmd == CMD_PINREAD && numBytes == 2) {
      pin = Wire.read();
      op = cmd;
      value = pinValue[digitalRead(myPins[pin])];
    }
    else if (cmd == CMD_PORTREAD && numBytes == 2) {
      pin = Wire.read();
      if (pin >= 0 && pin <= 6) {
        op = cmd;
        value = *pinsRegistry[pin];
      }
      else {
        op = ERROR;
      }
    }
	  else if (cmd == CMD_GETPINMODE && numBytes == 2) {
      op = cmd;
		  pin = Wire.read();
		  value = myPinsMode[pin] + 1;
	  }
	  else if (cmd == CMD_PINALLIN) {
      pin = Wire.read();
		  setInputs();
	  }
}    

void loop() {
}
